<template>
  <el-container>
    <el-header>
      菜品管理
      <el-avatar :size="size" :src="circleUrl">{{ this.user_name }}</el-avatar>
    </el-header>
    <el-container>
      <el-aside width="200px">
        <el-menu router background-color="#2b4b6b" text-color="#fff" active-text-color="#409eff">
          <el-submenu index="1">
            <template slot="title">
              <i class="el-icon-picture"></i>
              <span>商家菜品信息管理</span>
            </template>
            <el-menu-item index="/dish">
              <i class="el-icon-fork-spoon"></i>
              <span>菜品管理</span>
            </el-menu-item>
          </el-submenu>
          <el-menu-item index="/shell/dishdetail">
            <i class="el-icon-fork-spoon"></i>
            <span>用户订单</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>
<script>
import {eventBus} from "../store";

let user_name = ""

eventBus.$on('userinfo',(user_info)=>{
  user_name = user_info.username;
  console.log(user_name);
});


export default {
  data(){
    return{
      user_name:''
    }
  },
  mounted() {
    this.user_name = user_name;
  }
}
</script>
<style scoped>
.el-header {
  background-color: #2B4B6B;
  display: flex;
  justify-content: space-between;
  padding-left: 10px;
  align-items: center;
  color: white;
  font-size: 18px;
}

.el-aside {
  color: white;
  background-color: #2B4B6B;
}

.el-main {
  background-color: aliceblue;
}

.el-container {
  height: 100%;
}
</style>
