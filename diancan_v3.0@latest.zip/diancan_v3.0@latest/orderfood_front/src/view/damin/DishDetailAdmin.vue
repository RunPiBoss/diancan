<template>
  <el-card>
    <!--    面包屑组件-->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/welcome' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>我的餐桌</el-breadcrumb-item>
    </el-breadcrumb>
    <el-row :gutter="20">
      <el-col :span="8" >
        <el-tag type="">职员编号：{{this.user_table[0].user_id}}</el-tag>
        <el-tag type="success">管理员姓名：{{this.user_table[0].user_name}}</el-tag>
      </el-col>
      <el-col :span="4" offset="12">
        <router-link to="/selectdish">
          <el-button type="primary" icon="el-icon-right">返回菜品管理</el-button>
        </router-link>
      </el-col>
    </el-row>
    <el-table :data="tableData">
      <el-table-column label="菜名" prop="dish_name"/>
      <el-table-column label="菜品数量" prop="dish_num"/>
      <el-table-column label="菜品单价" prop="price"/>
      <el-table-column label="菜品总价">
        <template v-slot="scopes">
          <el-tag type="success">
            总价
            {{scopes.row.total_money}}
          </el-tag>
        </template>
      </el-table-column>
    </el-table>
  </el-card>
</template>


<script>
import {eventBus} from "../store"; //导入事件总线

let user_name = ""

eventBus.$on('userinfo',(user_info)=>{
  user_name = user_info.username;
  console.log(user_name);
});
export default {
  data() {
    return {
      tableData: [],
      user_name:'',
      user_table:{}
    }
  },
  methods: {
    search() {
      // 然后根据登录名称查询找整个用户的信息，用户id就是餐桌号
      this.searchUser();
      // 然后发起请求查询这个用户对应的餐桌
      this.$http.get('http://localhost:7514/desk/search?user_name='+user_name ).then(res => {
        console.log(res);
        if (res.data.code === 200) {
          this.tableData = res.data.data
          console.log(this.tableData);
        }
      }).catch(error => {
        this.$message.error(error);
      })
    },
    searchUser(){
      console.log(user_name)
      this.$http.get('http://localhost:7514/user/search-user?user_name='+user_name).then(res=>{
        if(res.data.code === 200){
          // console.log(res);
          this.user_table = res.data.data
          console.log(this.user_table[0].password)
        }
      }).catch(error => {
        this.$message.error("请重新登录");
      })
    },
  },

  mounted() {
    this.search();
  }
}
</script>

<style scoped>
.el-breadcrumb {
  padding: 20px;
}
</style>
