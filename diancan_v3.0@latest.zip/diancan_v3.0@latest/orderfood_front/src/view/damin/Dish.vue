<template>
  <el-card>
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/welcome' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>点餐系统数据分析</el-breadcrumb-item>
      <el-breadcrumb-item>菜品管理</el-breadcrumb-item>
    </el-breadcrumb>
    <!--最上面搜索框-->
    <el-row :gutter="10">
      <el-col :span="6">
        <el-input v-model="dish_name"  clearable @change="search" placeholder="请输入菜品名称查询"></el-input>
      </el-col>
      <el-col :span="6">
        <el-button type="primary" icon="el-icon-plus" @click="openAddDialog">添加</el-button>
      </el-col>
    </el-row>
    <!--中间查询显示界面-->
    <el-table :data="tableData">
      <el-table-column label="菜品编号" prop="dish_id"/>
      <el-table-column label="菜品名称" prop="dish_name"/>
      <el-table-column label="菜品介绍" prop="dish_des"/>
      <el-table-column label="价格" prop="price"/>
      <el-table-column label="操作">
        <template v-slot="scope">
          <el-button type="warning" size="small" icon="el-icon-edit" @click="openEditDialog(scope.row)">修改</el-button>
          <el-button type="danger" size="small" @click="remove(scope.row)" icon="el-icon-delete">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--    分页-->
    <el-pagination
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      :current-page="pager.page"
      :page-sizes="[5, 10, 15, 20]"
      :page-size="pager.size"
      layout="total, sizes, prev, pager, next, jumper"
      :total="pager.total">
    </el-pagination>
    <!--  添加对话框-->
    <el-dialog title="添加菜品信息" :visible.sync="addDialogFlag">
      <el-form :model="dish" :rules="rules" ref="dish" label-width="80px">
        <el-form-item label="菜品名称" prop="dish_name">
          <el-input v-model="dish.dish_name" placeholder="请输入菜品名称"></el-input>
        </el-form-item>
        <el-form-item label="菜品价格" prop="price">
          <el-input v-model="dish.price" placeholder="请输入菜品价格"></el-input>
        </el-form-item>
        <el-form-item label="菜品简介" >
          <el-input type="textarea" v-model="dish.dish_des" placeholder="请输入菜品简介"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addDialogFlag = false">关闭</el-button>
        <el-button type="primary" @click="save" >保存</el-button>
      </div>
    </el-dialog>

    <!--  修改对话框-->
    <el-dialog title="菜品信息修改" :visible.sync="editDialogFlag">
      <el-form :model="dish"  :rules=rules ref="dish" label-width="80px">

        <el-form-item label="菜品名称" prop="dish_name">
          <el-input v-model="dish.dish_name" placeholder="请输入菜品名称"></el-input>
        </el-form-item>
        <el-form-item label="菜品价格" prop="price">
          <el-input v-model="dish.price" placeholder="请输入菜品价格"></el-input>
        </el-form-item>
        <el-form-item label="菜品简介" >
          <el-input type="textarea" v-model="dish.dish_des" placeholder="请输入菜品简介"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="editDialogFlag = false">关闭</el-button>
        <el-button type="primary" @click="update" >保存</el-button>
      </div>
    </el-dialog>
  </el-card>

</template>
<script >
export default {
  data(){
    return{
      editDialogFlag:false,
      addDialogFlag:false,
      rules:{
        dish_id:[
          {
            required: true,
            message: '请输入菜品编号',
            trigger: 'blur'
          }
        ],
        dish_name:[
          {
            required: true,
            message: '请输入菜品名称',
            trigger: 'blur'
          }
        ],
        price:[
          {
            required: true,
            message: '请输入菜品价格',
            trigger: 'blur'
          }
        ],
        dish_des:[
          {
            required: true,
            message: '请输入菜品名称',
            trigger: 'blur'
          }
        ]
      },
      pager:{//定义分页对象
        page:1,
        size:5,
        total:0
      },
      dish:{},
      tableData:[],
      des:'',
      dish_name:'',
      price:0
    }
  },
  methods:{
    openEditDialog(row){//用来打开修改数据的对话框
      this.editDialogFlag=!this.editDialogFlag;
      this.dish=row;
    },
    openAddDialog() {
      this.addDialogFlag=!this.addDialogFlag;
    },
    handleCurrentChange(val){//改变当前处于第几条分页
      this.pager.page=val;
      this.search();
    },
    handleSizeChange(val){//处理最大页数，改变每页显示的最大记录条数
      this.pager.size=val;
      this.search();

    },
    // 查询
    search(){
      this.$http.get('http://localhost:7514/shelldish/list',{
        params:{
          page:this.pager.page,
          size:this.pager.size,
          dish_name:this.dish_name
        }
      })
        .then(res=>{
          if (res.data.code === 200){
            this.tableData = res.data.data.data;
            this.pager.total = res.data.data.total;
          }
        }).catch(error=>{
        this.$message.error("网络异常")
      })
    },
    remove(row){
      this.$http.get('http://localhost:7514/shelldish/remove?dish_id='+row.dish_id)
        .then(res=>{
          if(res.data){
            this.$message({
              message: '删除数据成功！！！',
              type: 'success'
            });
            this.search();
          }
        }).catch(error=>{
        this.$message({
          message: '删除数据成功',
          type: 'error'
        });
      })
    },
    save(){
      this.$refs['dish'].validate(valid=>{
        if(valid){
          this.$http.post('http://localhost:7514/shelldish/save',this.dish)
            .then(res=>{
              if(res.data.code===200){
                this.$message({
                  type:'success',
                  message:res.data.message
                })
                this.search()
                this.addDialogFlag=!this.addDialogFlag;
              }
            })
        }
      })
    },
    update(){
      this.$http.post('http://localhost:7514/shelldish/update',this.dish).then(res=>{
          if(res.data){
            this.$message({
              message: '修改成功',
              type: 'success'
            });
            this.search();
            this.editDialogFlag=!this.editDialogFlag;
          }
        }).catch(error=>{
        this.$message({
          message: '修改失败',
          type: 'warning'
        });
      })
    }
  },

  mounted() {
    this.search()
  }
}
</script>

<style scoped>
.el-breadcrumb{
  padding: 5px;
}
</style>
