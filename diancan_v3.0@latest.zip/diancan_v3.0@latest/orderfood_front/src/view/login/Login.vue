<template>
  <div class="login">
    <el-form ref="loginForm" :model="loginForm" :rules="loginRules">
      <el-form-item label="用户名" prop="username">
        <el-input v-model="loginForm.username"></el-input>
      </el-form-item>
      <el-form-item label="密码" prop="password">
        <el-input type="password" v-model="loginForm.password"></el-input>
      </el-form-item>
      <el-radio-group v-model="userType">
        <!--        0表示用户，1表示商家-->
        <el-radio :label="0">用户</el-radio>
        <el-radio :label="1">商家</el-radio>
      </el-radio-group>
      <el-form-item>
        <el-button type="warning" @click="login" class="login-button">登录</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import {eventBus} from "../store"; // 导入事件总线

export default {
  data() {
    return {
      page: '', // 页面信息，用于保存用户跳转的页面
      userType: 0,
      loginForm: {
        username: '',
        password: ''
      },
      loginRules: {
        username: [{required: true, message: '请输入用户名', trigger: 'blur'}],
        password: [{required: true, message: '请输入密码', trigger: 'blur'}]
      }
    };
  },
  methods: {
    login() {
      // 根据用户类型进行不同的登录处理
      if (this.userType === 0) {
        // 用户登录逻辑
        // post请求有多个参数的时候直接放在data里面，不需要再加params{}
        this.$http.post('http://localhost:7514/user/login', {
            user_name: this.loginForm.username,
            password: this.loginForm.password
        })
          .then(res => {
            console.log(this.loginForm)
            console.log(res.data)
            eventBus.$emit('userinfo', this.loginForm); // 发出需要传递的数据
            res.data === "Login successful" ? this.$router.push('/welcome') : this.$message.error("用户名或密码错误");
          }).catch(error => {
          this.$message.error("网络异常，稍后再试！！！！")
        })
        this.page = 'page1';
      } else if (this.userType === 1) {
        // 管理员登录逻辑
        this.$http.post('http://localhost:7514/user/login', {
            user_name: this.loginForm.username,
            password: this.loginForm.password
        })
          .then(res => {
            eventBus.$emit('userinfo', this.loginForm); // 发出需要传递的数据
            res.data === "Login successful" ? this.$router.push('/shell/welcome') : this.$message.error("用户名或密码错误");
          }).catch(error => {
          this.$message.error("网络异常，稍后再试！！！！")
        })
        // console.log('商家登录');
        // this.page = 'page2'; // 设置页面为page2
      }
    }
  }
};
</script>

<style scoped>
.login {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background-image: url('../../../static/img/980.jpg');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}

.el-radio-group {
  margin-bottom: 20px;
}

.login-button {
  width: 100%; /* 设置按钮宽度为100% */
}
</style>
