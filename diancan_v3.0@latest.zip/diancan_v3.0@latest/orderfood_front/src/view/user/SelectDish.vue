<template>
<!--卡片组件-->
  <el-card>
<!--    面包屑组件-->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/welcome' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item>菜单</el-breadcrumb-item>
      <el-breadcrumb-item>详细菜单</el-breadcrumb-item>
    </el-breadcrumb>
    <el-row :gutter="10">
      <el-col :span="6">
        <el-input v-model="dish_name" clearable @change="search" placeholder="请输入类别名称查询"></el-input>
      </el-col>
    </el-row>
<!--    表格组件-->
    <el-table :data="tableData">
      <el-table-column label="菜名" prop="dish_name"/>
      <el-table-column label="菜品描述" prop="dish_des"/>
      <el-table-column label="价格" prop="price"/>
      <el-table-column label="操作">
<!--        按钮组件-->
        <template v-slot="scope">
          <el-button type="primary" size="small" icon="el-icon-plus" @click="addToDesk(scope.row)">添加到餐桌</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--    分页组件-->
    <div style="display: flex; justify-content: space-between;">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="pager.page"
        :page-sizes="[5, 10, 15, 20]"
        :page-size="pager.size"
        layout="total, sizes, prev, pager, next, jumper"
        :total="pager.total"
        style="flex-grow: 1;">
      </el-pagination>
      <el-button  type="success" style="margin-left: 100px" @click="opendrawer">餐桌</el-button>
    </div>
<!--    抽屉组件-->
    <el-drawer
      title="这些美食将出现在您的餐桌上:"
      :visible.sync="drawer"
      :direction="direction"
      :before-close="handleClose">
      <span>
        <template>
          <el-table :data="selectedDishes">
             <el-table-column label="菜名" prop="dish_name"></el-table-column>
             <el-table-column label="价格" prop="price"></el-table-column>
            <el-table-column label="操作">
              <template v-slot="scope">
                <el-button type="primary" size="small" icon="el-icon-delete-solid" @click="removefromdesk(scope.$index)">不想吃这个了</el-button>
              </template>
            </el-table-column>
          </el-table>
          <div class="bottom-bar">
            <el-button type="success" size="medium" @click="placeOrder">下单</el-button>
          </div>
        </template>
      </span>
    </el-drawer>
  </el-card>
</template>
<!--行为区，主要编写脚本代码，js代码编辑区-->
<script>
// export对外暴露一个Vue对象
export default {
  data(){
    return{
      // 定义变量
      isOrderPlaced:false,//下单状态，默认为未成功
      selectedDishes:[],
      selectedDish:{},
      drawer:false,
      direction:'rtl',
      addDialogFlag:false,//添加对话框显示标记，默认false不显示
      editDialogFlag:false,
      pager:{
        page:1,
        size:5,
        total:0
      },
      rules:{//定义验证表单规则
        dish_name:[{ required: true, message: '请输入菜品名称', trigger: 'blur' }]
      },
      tableData:[],
      dish_name:'',
      dish:{},
      dishes:[],
      selectedDishesInfo:[],
      orderData:{},
      // 餐桌号的id，等于用户的id
      t_desk_id:1
    }
  },
  // 生命周期函数，该函数的特点是浏览器渲染Vue组件时立刻执行
  mounted() {
    this.search();
  },
  methods:{
     placeOrder(){
        try {
          // 获取已选择菜品的名称和单价，并统计菜品数量和订单中菜品的总和
          const selectedDishesInfo = this.selectedDishes.map(dish => {
            return {
              dish_name: dish.dish_name, // 获取 dish 对象的 name 属性
              price: dish.price // 获取 dish 对象的 price 属性
            };
          });
          const dishCount = this.selectedDishes.length;
          const orderTotal = this.selectedDishes.reduce((total, dish) => {
            return total + dish.price;
          }, 0);
          this.$http.post('http://localhost:7514/desk/save',{
            dish_name: selectedDishesInfo[0].dish_name, // 获取 dish 对象的 name 属性
            price: selectedDishesInfo[0].price,
            dish_num:dishCount,
            total_money:orderTotal,
            t_desk_id: this.t_desk_id
          }).then(res=>{
            if (res.data.code === 200){
              this.$message({
                type:'success',
                message:res.data.message
              })
              this.isOrderPlaced = true;
            }
          }).catch(error=>{
            alert('wewewewe')
          })
        }catch (error){
          this.$message.error("网络异常")
        }
    },
    opendrawer(){
      this.drawer = true; // 打开抽屉
    },
    removefromdesk(index){
      this.selectedDishes.splice(index, 1); // 从selectedDishes数组中删除对应的菜品
    },
    handleClose(done){
      this.$confirm('确认收起餐桌预览吗?').then(_=>{
        done();
      })
        .catch(_=>{})
    },
    addToDesk(row) {
      const isDuplicate = this.selectedDishes.some(dish => dish.dish_name === row.dish_name);
      if (isDuplicate) {
        this.$message.error('该菜品已经添加到餐桌上了');
        return;
      }
      const selectedDish = {
        dish_name: row.dish_name,
        price: row.price,
      };
      this.selectedDishes.push(selectedDish); // 将当前行的数据赋值给selectedDish
      this.$message.success('已成功添加到餐桌')
    },
    handleCurrentChange(val){//处理改变当前从第几条分页
      this.pager.page = val;
      this.search();
    },
    handleSizeChange(val){//处理最大的页数，改变每页实现最多的条数
      this.pager.size = val;
      this.search();
    },
    search(){
      this.$http.get('http://localhost:7514/dish/list',{
        params:{
          page:this.pager.page,
          size:this.pager.size,
          dish_name:this.dish_name
        }
      })
        .then(res=>{
            if (res.data.code === 200){
              this.tableData = res.data.data.data;
              this.pager.total = res.data.data.total;
            }
        }).catch(error=>{
          this.$message.error("网络异常")
      })
    }
  }
}
</script>
<style scoped>
.el-breadcrumb{
  padding: 5px;
}
</style>
