import Vue from 'vue'
import Router from 'vue-router'
import SelectDish from "../view/user/SelectDish.vue";
import Main from "../view/user/Main.vue";
import Welcome from "../components/Welcome.vue";
import DishDetail from "../view/user/DishDetail.vue"
import Shell from "../view/damin/Shell.vue"
import Dish from "../view/damin/Dish.vue";
import Login from "../view/login/Login.vue";
import DishDetailAdmin from "../view/damin/DishDetailAdmin.vue";


Vue.use(Router)

export default new Router({
  routes: [
    // 登录界面
    {
      path: '/login',
      name: 'Login',
      component: Login
    },
    // 用户界面
    {
      path: '/',
      name: 'Main',
      component: Main,
      redirect: '/login',
      children: [
        {
          path: '/welcome',
          name: 'welcome',
          component: Welcome,
        },
        {
          path: '/selectdish',
          name: 'selectdish',
          component: SelectDish,
        },
        {
          path: '/dishdetail',
          name: 'DishDetail',
          component: DishDetail,
        },
        {
          path: '/welcome',
          name: 'Welcome',
          component: Welcome
        }
      ]
    },
    //商家界面
    {
      path: '/shell',
      name: 'Shell',
      component: Shell,
      redirect: '/login',
      children: [
        {
          path: '/dish',
          name: 'Dish',
          component: Dish
        },
        {
          path: '/shell/dishdetail',
          name: 'DishDetailAdmin',
          component: DishDetailAdmin,
        },
        {
          path: '/shell/welcome',
          name: 'Welcome',
          component: Welcome
        }
      ]
    }
  ]
})
