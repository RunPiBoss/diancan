package com.orderfood.app.controller;

import com.orderfood.app.bean.Dish;
import com.orderfood.app.service.DishService;
import com.orderfood.app.utils.CommonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(tags = "菜品API文档")
@RestController
@RequestMapping("/dish")
@CrossOrigin(origins = "http://localhost:8080")
public class DishController {
    @Autowired
    private DishService dishService;

    @ApiOperation("查询菜品信息")
    @GetMapping("/list")
    public CommonResult Pagerlist(int page,int size,String dish_name){
        Map<String,Object>map = new HashMap<>();
        map.put("data",dishService.listPager(page, size,dish_name));
        map.put("total",dishService.count(dish_name));
        return CommonResult.success(map);
    }

    @ApiOperation("添加菜品信息")
    @PostMapping("/save")
    public CommonResult save(@RequestBody Dish dish){
        return CommonResult.success(dishService.saveCategory(dish));
    }
}
