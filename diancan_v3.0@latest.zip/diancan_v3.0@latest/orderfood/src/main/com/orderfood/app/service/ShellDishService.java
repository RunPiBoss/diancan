package com.orderfood.app.service;

import com.orderfood.app.bean.Dish;

import java.util.List;

public interface ShellDishService {
    List<Dish> listPager(int page, int size, String dish_name);
    int count(String dish_name);
    boolean removeDish(int dish_id);

    boolean save(Dish dish);

    boolean update(Dish dish);
}
