package com.orderfood.app.service;
import com.orderfood.app.bean.Dish;
import java.util.List;
public interface DishService {
    List<Dish>listPager(int page,int size,String dish_name);
    int count(String dish_name);

    boolean saveCategory(Dish dish);
}
