package com.orderfood.app.service.impl;

import com.orderfood.app.bean.User;
import com.orderfood.app.dao.UserDao;
import com.orderfood.app.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserDao userDao;


    public boolean validateUser(String username, String password) {
        User user = userDao.getUserByUsername(username, password);
        if (user != null && user.getPassword().equals(password)) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public List<User> searchUser(String user_name) {
        return userDao.searchUser(user_name);
    }
}
