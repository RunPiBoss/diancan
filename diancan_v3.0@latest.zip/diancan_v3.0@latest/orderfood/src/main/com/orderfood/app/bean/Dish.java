package com.orderfood.app.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Dish implements Serializable{
    private Integer dish_id;
    private String dish_name;
    private String dish_des;
    private Integer price;
}
