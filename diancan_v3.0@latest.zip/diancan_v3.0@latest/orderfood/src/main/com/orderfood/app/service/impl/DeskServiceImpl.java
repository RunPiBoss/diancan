package com.orderfood.app.service.impl;

import com.orderfood.app.bean.Desk;
import com.orderfood.app.bean.User;
import com.orderfood.app.dao.DeskDao;
import com.orderfood.app.service.DeskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeskServiceImpl implements DeskService {
    @Autowired
    private DeskDao deskDao;
    @Override
    public boolean saveDesk(Desk desk) {
        return deskDao.insert(desk) > 0?true:false;
    }

    @Override
    public List<Desk> searchMyDesk(String user_name) {
        return deskDao.searchMyDesk(user_name);
    }

    @Override
    public List<User> serachUser() {
        return deskDao.searchUser();
    }
}
