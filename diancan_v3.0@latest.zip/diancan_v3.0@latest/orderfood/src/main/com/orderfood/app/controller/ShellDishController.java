package com.orderfood.app.controller;

import com.orderfood.app.bean.Dish;
import com.orderfood.app.utils.CommonResult;
import com.orderfood.app.service.ShellDishService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@Api(value = "菜品api文档")
@RestController
@RequestMapping("/shelldish" )
@CrossOrigin
public class ShellDishController {
    @Autowired
    private ShellDishService shellDishService;

    @ApiOperation("查询菜品信息")
    @RequestMapping("/list")
    public CommonResult listPager(int page, int size, String dish_name) {
        Map<String, Object> map = new HashMap<>();
        map.put("data", shellDishService.listPager(page, size, dish_name));
        map.put("total", shellDishService.count(dish_name));
        return CommonResult.success(map);
    }

    @ApiOperation("根据id删除菜品信息")
    @RequestMapping("/remove")
    public CommonResult remove(int dish_id) {
        return CommonResult.success(shellDishService.removeDish(dish_id));
    }

    @ApiOperation("添加菜品信息")
    @RequestMapping("/save")
    public CommonResult save(@RequestBody Dish dish) {
        return CommonResult.success(shellDishService.save(dish));
    }
    @ApiOperation("修改菜品信息")
    @RequestMapping("/update")
    public CommonResult update(@RequestBody Dish dish){
        return CommonResult.success(shellDishService.update(dish));
    }
}
