package com.orderfood.app.dao;

import com.orderfood.app.bean.Desk;
import com.orderfood.app.bean.User;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DeskDao {
    int insert(Desk desk);

    List<Desk>searchMyDesk(String user_name);


    List<User> searchUser();
}
