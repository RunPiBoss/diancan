package com.orderfood.app.service.impl;

import com.orderfood.app.bean.Dish;

import com.orderfood.app.dao.ShellDishDao;
import com.orderfood.app.service.ShellDishService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShellDishServiceImpl implements ShellDishService {
    @Autowired

    private ShellDishDao shellDishDao;
    @Override
    public List<Dish> listPager(int page, int size, String dish_name) {
        return shellDishDao.listPager((page-1)*size,size,dish_name);
    }

    @Override
    public int count(String dish_name) {
        return shellDishDao.count(dish_name);
    }

    @Override
    public boolean removeDish(int dish_id) {
        return shellDishDao.delete(dish_id)>0?true:false;
    }

    @Override
    public boolean save(Dish dish) {
        return shellDishDao.save(dish)>0?true:false;
    }

    @Override
    public boolean update(Dish dish) {
        return shellDishDao.update(dish)>0?true:false;
    }
}
