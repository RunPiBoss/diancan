package com.orderfood.app.controller;

import com.orderfood.app.bean.Desk;
import com.orderfood.app.service.DeskService;
import com.orderfood.app.utils.CommonResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.plugin.core.config.EnablePluginRegistries;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Api(tags = "餐桌API文档")
@RestController
@RequestMapping("/desk")
@CrossOrigin    //主要作用是用来处理跨服务器访问数据的问题
public class DeskController {
    @Autowired
    private DeskService deskService;

    @ApiOperation("添加菜品信息")
    @PostMapping("/save")
    public CommonResult save(@RequestBody Desk desk){
        return CommonResult.success(deskService.saveDesk(desk));
    }

    @ApiOperation("我的菜品信息")
    @GetMapping("/search")
    public CommonResult search(String user_name){
        return CommonResult.success(deskService.searchMyDesk(user_name));
    }
}
