package com.orderfood.app.controller;

import com.orderfood.app.bean.User;
import com.orderfood.app.service.UserService;
import com.orderfood.app.utils.CommonResult;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@Api(value = "用户")
@RestController
@RequestMapping("/user" )
//@RestController
@CrossOrigin
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public String login(@RequestBody User user) {
        boolean isValidUser = userService.validateUser(user.getUser_name(), user.getPassword());
        System.out.println(isValidUser);
        if (isValidUser) {
            return "Login successful";
        } else {
            return "Invalid credentials";
        }
    }

    @GetMapping("/search-user")
    public CommonResult searchUser(String user_name){
        return CommonResult.success(userService.searchUser(user_name));
    }
}