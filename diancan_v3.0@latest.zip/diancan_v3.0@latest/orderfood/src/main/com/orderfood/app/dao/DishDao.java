package com.orderfood.app.dao;

import com.orderfood.app.bean.Dish;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DishDao {
    List<Dish>listPaqer(@Param("page") int page, @Param("size") int size,@Param("dish_name")String dish_name);

    int count(@Param("dish_name")String dish_name);

    int insert(Dish dish);

}
