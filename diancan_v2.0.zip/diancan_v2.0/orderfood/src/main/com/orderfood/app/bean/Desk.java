package com.orderfood.app.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Desk implements Serializable {
    private Integer desk_id;
    private String dish_name;
    private Integer price;
    private Integer total_money;
    private Integer dish_num;
    private Integer t_desk_id;
}
