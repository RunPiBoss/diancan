package com.orderfood.app.service;

import com.orderfood.app.bean.User;

import java.util.List;

public interface UserService {
//    boolean loginService(String username, String password);
    boolean validateUser(String username, String password);

    List<User> searchUser(String user_name);
}
