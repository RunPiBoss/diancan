package com.orderfood.app.service.impl;

import com.orderfood.app.bean.Dish;
import com.orderfood.app.dao.DishDao;
import com.orderfood.app.service.DishService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DishServiceImpl implements DishService {
    @Autowired
    private DishDao dishDao;

    public List<Dish> listPager(int page,int size,String dish_name){
        return dishDao.listPaqer((page - 1) * size,size,dish_name);
    }
    public int count(String dish_name){
        return  dishDao.count(dish_name);
    }

    @Override
    public boolean saveCategory(Dish dish) {
        return dishDao.insert(dish) > 0?true:false;
    }
}
