package com.orderfood.app.dao;

import com.orderfood.app.bean.User;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserDao {
    User getUserByUsername(String user_name,String password);

    List<User> searchUser(String user_name);
}
