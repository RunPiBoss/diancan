package com.orderfood.app;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.orderfood.app.dao")
public class SpringDishApp {
    public static void main(String[] args) {
        SpringApplication.run(SpringDishApp.class);
    }
}
