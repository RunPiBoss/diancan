package com.orderfood.app.service;

import com.orderfood.app.bean.Desk;
import com.orderfood.app.bean.User;

import java.util.List;

public interface DeskService {
    boolean saveDesk(Desk desk);
    List<Desk> searchMyDesk(String user_name);

    List<User> serachUser();
}
