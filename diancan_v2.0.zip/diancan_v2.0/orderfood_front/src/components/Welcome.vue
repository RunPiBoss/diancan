<script setup>

</script>

<template>
<div>
  欢迎界面
</div>
</template>

<style scoped>

</style>
