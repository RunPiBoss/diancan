// 这是进行数据传递的文件，不要动
import Vue from 'vue';

// 创建事件总线
export const eventBus = new Vue();
