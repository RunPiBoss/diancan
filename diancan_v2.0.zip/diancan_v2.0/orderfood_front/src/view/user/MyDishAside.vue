<script setup>

</script>

<template>
  <el-menu-item index="/dishdetail" >
    <i class="el-icon-dish"></i>
    <span slot="title">我的餐桌</span>
  </el-menu-item>
</template>

<style scoped>

</style>
