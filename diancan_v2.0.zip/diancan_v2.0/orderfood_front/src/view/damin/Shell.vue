<template>
  <el-container>
    <el-header>菜品管理</el-header>
    <el-container>
      <el-aside width="200px">
        <el-menu router background-color="#2b4b6b" text-color="#fff" active-text-color="#409eff">
          <el-submenu index="1">
            <template slot="title">
              <i class="el-icon-picture"></i>
              <span>商家菜品信息管理</span>
            </template>
            <el-menu-item index="/dish">
              <i class="el-icon-fork-spoon"></i>
              <span>菜品管理</span>
            </el-menu-item>
          </el-submenu>
        </el-menu>
      </el-aside>
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>
<script >

</script>
<style scoped>
.el-header {
  background-color: #2B4B6B;
  display: flex;
  justify-content: space-between;
  padding-left: 10px;
  align-items: center;
  color: white;
  font-size: 18px;
}
.el-aside {
  color: white;
  background-color: #2B4B6B;
}
.el-main {
  background-color: aliceblue;
}
.el-container {
  height: 100%;}
</style>
